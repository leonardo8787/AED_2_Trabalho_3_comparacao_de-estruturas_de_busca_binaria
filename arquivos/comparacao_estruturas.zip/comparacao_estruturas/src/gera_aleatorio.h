#ifndef gera_aleatorio_h
#define gera_aleatorio_h

#include<stdio.h>
#include<stdlib.h>
#include<time.h>

bool Existe(int valores[], int tam, int valor);

void GerarAleatorios(int numeros[], int quantNumeros, int Limite);

#endif